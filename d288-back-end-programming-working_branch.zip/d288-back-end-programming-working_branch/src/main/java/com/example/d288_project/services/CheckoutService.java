package com.example.d288_project.services;

public interface CheckoutService {
    PurchaseResponse placeOrder(Purchase purchase);
}
