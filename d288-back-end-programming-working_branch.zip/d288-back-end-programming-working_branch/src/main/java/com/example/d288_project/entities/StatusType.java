package com.example.d288_project.entities;

public enum StatusType {
    pending, ordered, cancelled
}
